﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_Adventure
{
    public class Item : GameObject
    {
        public Item(string[] idents, string name, string description) : base(idents,name,description)
        {

        }
    }
}
